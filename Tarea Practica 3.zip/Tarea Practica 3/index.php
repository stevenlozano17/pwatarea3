<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Menú de Ejercicios PHP</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/estilo.css">
</head>
<body>

    <div class="container text-center py-5">
        <h1 class="fw-bold mb-4 text-white">🧩 TAREA PRÁCTICA 3 — Ejercicios PHP</h1>

        <div class="row justify-content-center g-4">

            <div class="col-md-4 col-lg-3">
                <div class="card bg-primary p-4 shadow-sm">
                    <a href="ejercicios/ej01/ej01.html" class="text-white text-decoration-none fw-bold">
                        Ejercicio 1<br><small>Menú Desplegable</small>
                    </a>
                </div>
            </div>

            <div class="col-md-4 col-lg-3">
                <div class="card bg-success p-4 shadow-sm">
                    <a href="ejercicios/ej02/ej02.html" class="text-white text-decoration-none fw-bold">
                        Ejercicio 2<br><small>Formulario de Contacto</small>
                    </a>
                </div>
            </div>

            <div class="col-md-4 col-lg-3">
                <div class="card bg-warning p-4 shadow-sm">
                    <a href="ejercicios/ej03/ej03.php" class="text-dark text-decoration-none fw-bold">
                        Ejercicio 3<br><small>Contador de Visitas</small>
                    </a>
                </div>
            </div>

            <div class="col-md-4 col-lg-3">
                <div class="card bg-danger p-4 shadow-sm">
                    <a href="ejercicios/ej04/ej04.php" class="text-white text-decoration-none fw-bold">
                        Ejercicio 4<br><small>Juego de Adivinanzas</small>
                    </a>
                </div>
            </div>

            <div class="col-md-4 col-lg-3">
                <div class="card bg-info p-4 shadow-sm">
                    <a href="ejercicios/ej05/ej05.php" class="text-dark text-decoration-none fw-bold">
                        Ejercicio 5<br><small>Galería de Imágenes</small>
                    </a>
                </div>
            </div>

            <div class="col-md-4 col-lg-3">
                <div class="card bg-dark p-4 shadow-sm">
                    <a href="ejercicios/ej06/ej06.php" class="text-white text-decoration-none fw-bold">
                        Ejercicio 6<br><small>Sistema de Login</small>
                    </a>
                </div>
            </div>
        </div>
    </div>

    <footer class="mt-5 text-center">
        <p class="text-light-50">&copy; <?php echo date("Y"); ?> — Desarrollado por <strong>Steven Lozano</strong></p>
    </footer>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
