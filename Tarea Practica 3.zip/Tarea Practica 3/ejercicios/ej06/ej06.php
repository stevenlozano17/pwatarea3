<?php
session_start();

$usuarios = [
    "admin" => "1234",
    "usuario" => "abcd",
    "steven" => "2025"
];

$error = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $usuario = $_POST["usuario"];
    $password = $_POST["password"];

    if (isset($usuarios[$usuario]) && $usuarios[$usuario] == $password) {
        $_SESSION["usuario"] = $usuario;

        header("Location: tienda/tienda.php"); 
        exit();
    } else {
        $error = "Usuario o contraseña incorrectos.";
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Ejercicio 6</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/estilo.css">
</head>
<body>
    <div class="login-container">
        <div class="card p-5 shadow-lg bg-dark text-light">
            <h2 class="text-center mb-4 text-success">🔐 Iniciar Sesión</h2>
            
            <?php if ($error): ?>
                <div class="alert alert-danger text-center"><?= $error ?></div>
            <?php endif; ?>

            <form method="POST" action="">
                <div class="mb-3">
                    <label for="usuario" class="form-label text-success">Usuario</label>
                    <input type="text" class="form-control" id="usuario" name="usuario" placeholder="Ingresa tu usuario" required>
                </div>

                <div class="mb-3">
                    <label for="password" class="form-label text-success">Contraseña</label>
                    <input type="password" class="form-control" id="password" name="password" placeholder="Ingresa tu contraseña" required>
                </div>

                <button type="submit" class="btn btn-success w-100 mt-3">Entrar</button>
            </form>
                <div class="text-center mt-4">
                    <a href="../../index.php" class="btn btn-outline-success">
                        🏠 Regresar al Menú Principal
                    </a>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
