<?php include('includes/productos.php'); ?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tienda Online</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="ejercicios/ej06/tienda/css/estilo.css">
</head>
<body class="bg-light">

    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand fw-bold" href="index.php">Mi Tienda</a>
            <div class="d-flex gap-2">
                <a href="productos.html" class="btn btn-outline-light">
                    🛒 Ver Carrito (<span id="contador">0</span>)
                </a>
                <a href="../ej06.php" class="btn btn-outline-danger fw-bold">🚪 Salir</a>
            </div>
        </div>
    </nav>

    <div class="container py-5">
        <h2 class="mb-4 text-center">Nuestros Productos</h2>
        <div class="row g-4">
            <?php foreach($productos as $producto): ?>
                <div class="col-md-4">
                    <div class="card shadow-sm h-100">
                        <img src="<?= $producto['imagen'] ?>" class="card-img-top" alt="<?= $producto['nombre'] ?>">
                        <div class="card-body">
                            <h5 class="card-title"><?= $producto['nombre'] ?></h5>
                            <p class="card-text"><?= $producto['descripcion'] ?></p>
                            <p class="text-success fw-bold">$<?= number_format($producto['precio'], 2) ?></p>
                            <button class="btn btn-primary w-100 agregarCarrito"
                                data-id="<?= $producto['id'] ?>"
                                data-nombre="<?= $producto['nombre'] ?>"
                                data-precio="<?= $producto['precio'] ?>">
                                Agregar al carrito
                            </button>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="ejercicios/ej06/tienda/js/carrito.js"></script>
</body>
</html>
