document.addEventListener("DOMContentLoaded", () => {
    let carrito = JSON.parse(localStorage.getItem("carrito")) || [];
    const contador = document.getElementById("contador");

    actualizarContador();

    document.querySelectorAll(".agregarCarrito").forEach(boton => {
        boton.addEventListener("click", () => {
            const id = boton.dataset.id;
            const nombre = boton.dataset.nombre;
            const precio = parseFloat(boton.dataset.precio);
            const imgElement = boton.closest(".card").querySelector("img");
            let imagen = imgElement.getAttribute("src");
            console.log("Ruta original de la imagen:", imagen);
            imagen = imagen.replace(/^.*[\\\/]imagenes[\\\/]/, 'imagenes/');

            const productoExistente = carrito.find(p => p.id === id);

            if (productoExistente) {
                productoExistente.cantidad++;
            } else {
                carrito.push({ id, nombre, precio, cantidad: 1, imagen });
            }

            localStorage.setItem("carrito", JSON.stringify(carrito));
            actualizarContador();

            boton.innerText = "✔ Agregado";
            boton.classList.remove("btn-primary");
            boton.classList.add("btn-success");

            setTimeout(() => {
                boton.innerText = "Agregar al carrito";
                boton.classList.remove("btn-success");
                boton.classList.add("btn-primary");
            }, 1000);
        });
    });

    function actualizarContador() {
        if (contador) {
            const totalItems = carrito.reduce((acc, item) => acc + item.cantidad, 0);
            contador.textContent = totalItems;
        }
    }
});

