document.addEventListener("DOMContentLoaded", () => {
    let carrito = JSON.parse(localStorage.getItem("carrito")) || [];
    console.log("Contenido del carrito:", carrito);
    
    const contenedor = document.getElementById("carrito");
    const btnVaciar = document.getElementById("vaciarCarrito");

    function renderCarrito() {
        if (carrito.length === 0) {
            contenedor.innerHTML = `
                <div class="alert alert-warning text-center">
                    Tu carrito está vacío 😢
                </div>`;
            return;
        }

        let total = 0;
        let html = `
        <table class="table table-bordered table-striped align-middle text-center">
            <thead class="table-dark">
                <tr>
                    <th>Imagen</th>
                    <th>Producto</th>
                    <th>Precio</th>
                    <th>Cantidad</th>
                    <th>Subtotal</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>`;

        carrito.forEach((p, index) => {
            const subtotal = p.precio * p.cantidad;
            total += subtotal;

            html += `
                <tr>
                    <td><img src="${p.imagen}" class="img-thumbnail" style="width: 60px; height: 60px; object-fit: cover;"></td>
                    <td>${p.nombre}</td>
                    <td>$${p.precio.toFixed(2)}</td>
                    <td>
                        <div class="d-flex justify-content-center align-items-center gap-2">
                            <button class="btn btn-sm btn-outline-secondary" onclick="cambiarCantidad(${index}, -1)">−</button>
                            <span>${p.cantidad}</span>
                            <button class="btn btn-sm btn-outline-secondary" onclick="cambiarCantidad(${index}, 1)">+</button>
                        </div>
                    </td>
                    <td>$${subtotal.toFixed(2)}</td>
                    <td>
                        <button class="btn btn-sm btn-danger" onclick="eliminarProducto(${index})">🗑 Eliminar</button>
                    </td>
                </tr>`;
        });

        html += `
            </tbody>
        </table>
        <h4 class="text-end">Total: <span class="text-success fw-bold">$${total.toFixed(2)}</span></h4>
        `;

        contenedor.innerHTML = html;
    }

    window.cambiarCantidad = (index, cambio) => {
        carrito[index].cantidad += cambio;
        if (carrito[index].cantidad <= 0) carrito.splice(index, 1);
        guardarYActualizar();
    };

    window.eliminarProducto = (index) => {
        carrito.splice(index, 1);
        guardarYActualizar();
    };

    btnVaciar.addEventListener("click", () => {
        if (confirm("¿Seguro que deseas vaciar el carrito?")) {
            carrito = [];
            guardarYActualizar();
        }
    });

    function guardarYActualizar() {
        localStorage.setItem("carrito", JSON.stringify(carrito));
        renderCarrito();
    }

    renderCarrito();
});
