<?php
$productos = [
    [
        "id" => 1,
        "nombre" => "Auriculares Bluetooth",
        "descripcion" => "Auriculares inalámbricos con cancelación de ruido y micrófono integrado.",
        "precio" => 25.99,
        "imagen" => "imagenes/auriculares_inalambricos.jpg"
    ],
    [
        "id" => 2,
        "nombre" => "Smartwatch Deportivo",
        "descripcion" => "Reloj inteligente con monitoreo cardíaco, GPS y resistencia al agua.",
        "precio" => 49.99,
        "imagen" => "imagenes/smartwatch_deportivo.jpg"
    ],
    [
        "id" => 3,
        "nombre" => "Teclado Mecánico RGB",
        "descripcion" => "Teclado gamer con retroiluminación RGB y switches mecánicos azules.",
        "precio" => 59.90,
        "imagen" => "imagenes/teclado_mecanico.jpg"
    ],
    [
        "id" => 4,
        "nombre" => "Mouse Inalámbrico",
        "descripcion" => "Mouse ergonómico inalámbrico con conexión Bluetooth 5.0.",
        "precio" => 19.99,
        "imagen" => "imagenes/mouse_inalambrico.png"
    ],
    [
        "id" => 5,
        "nombre" => "Laptop 15.6''",
        "descripcion" => "Laptop con procesador Intel Core i7, 16GB RAM y SSD de 512GB.",
        "precio" => 899.00,
        "imagen" => "imagenes/laptop_15_6.jpg"
    ],
    [
        "id" => 6,
        "nombre" => "Monitor LED 27''",
        "descripcion" => "Monitor Full HD con bordes ultrafinos y tecnología antirreflejo.",
        "precio" => 179.50,
        "imagen" => "imagenes/monitor_27pulg.jpg"
    ],
    [
        "id" => 7,
        "nombre" => "Cámara Web HD",
        "descripcion" => "Cámara web 1080p ideal para videollamadas y streaming.",
        "precio" => 39.99,
        "imagen" => "imagenes/webcam.jpg"
    ]
];
?>
