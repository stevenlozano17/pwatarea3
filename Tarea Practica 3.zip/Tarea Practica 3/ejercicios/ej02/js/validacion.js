document.addEventListener("DOMContentLoaded", function() {
  const form = document.getElementById("contactForm");
  const alerta = document.getElementById("alertaFormulario");

  form.addEventListener("submit", function(event) {
    event.preventDefault();

    const nombre = document.getElementById("nombre");
    const correo = document.getElementById("correo");
    const mensaje = document.getElementById("mensaje");

    let valido = true;

    if (nombre.value.trim() === "") {
      nombre.classList.add("is-invalid");
      valido = false;
    } else {
      nombre.classList.remove("is-invalid");
      nombre.classList.add("is-valid");
    }

    const regexCorreo = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!regexCorreo.test(correo.value.trim())) {
      correo.classList.add("is-invalid");
      valido = false;
    } else {
      correo.classList.remove("is-invalid");
      correo.classList.add("is-valid");
    }

    if (mensaje.value.trim() === "") {
      mensaje.classList.add("is-invalid");
      valido = false;
    } else {
      mensaje.classList.remove("is-invalid");
      mensaje.classList.add("is-valid");
    }

    if (!valido) {
      alerta.className = "alert alert-warning mt-3";
      alerta.textContent = "⚠️ Por favor, completa todos los campos antes de enviar el formulario.";
      alerta.classList.remove("d-none");
    } else {
      alerta.className = "alert alert-success mt-3";
      alerta.textContent = "✅ Formulario enviado correctamente. ¡Gracias por contactarnos!";
      alerta.classList.remove("d-none");

      form.reset();
      [nombre, correo, mensaje].forEach(campo => campo.classList.remove("is-valid"));
    }
  });
});
