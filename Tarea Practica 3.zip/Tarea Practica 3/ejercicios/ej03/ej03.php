<?php
$archivo = "data/contador.txt";

if (!file_exists($archivo)) {
    file_put_contents($archivo, "0");
}

$visitas = (int) file_get_contents($archivo);
$visitas++;
file_put_contents($archivo, $visitas);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contador de Visitas</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/estilo.css">
</head>
<body class="bg-dark text-center text-success">

    <div class="container py-5">
        <h1 class="fw-bold mb-4">CONTADOR DE VISITAS</h1>
        <div class="contador display-1 fw-bold mb-5"><?php echo $visitas; ?></div>
        <div class="text-center">
            <a href="../../index.php" class="btn btn-outline-success btn-lg">🏠 Regresar al Menú Principal</a>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
