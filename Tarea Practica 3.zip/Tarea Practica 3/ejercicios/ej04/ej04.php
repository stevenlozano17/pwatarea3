<?php
session_start();

if (!isset($_SESSION['numeroSecreto'])) {
    $_SESSION['numeroSecreto'] = rand(1, 10); 
}

$mensaje = "";
$mostrarBotonReiniciar = false;

if (isset($_POST['adivinanza'])) {
    $intento = (int) $_POST['adivinanza'];
    $numeroSecreto = $_SESSION['numeroSecreto'];

    if ($intento === $numeroSecreto) {
        $mensaje = "🎉 ¡Correcto! El número era $numeroSecreto.";
        $mostrarBotonReiniciar = true;
    } elseif ($intento < $numeroSecreto) {
        $mensaje = "🔻 Demasiado bajo. Intenta un número más alto.";
    } else {
        $mensaje = "🔺 Demasiado alto. Intenta un número más bajo.";
    }
}

if (isset($_POST['reiniciar'])) {
    unset($_SESSION['numeroSecreto']);
    header("Location: ej04.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Juego de Adivinanzas</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/estilo.css">
</head>
<body class="bg-light d-flex align-items-center justify-content-center vh-100">

    <div class="container text-center">
        <div class="card p-5 shadow-lg mx-auto" style="max-width: 400px;">
            <h1 class="mb-3">🎲 Juego de Adivinanzas</h1>
            <p class="text-muted">Adivina el número entre <strong>1</strong> y <strong>10</strong>.</p>

            <?php if (!$mostrarBotonReiniciar): ?>
                <form method="POST" onsubmit="return validarEntrada();" class="mt-4">
                    <div class="mb-3">
                        <input type="number" name="adivinanza" id="adivinanza" 
                               class="form-control text-center" placeholder="Escribe tu número" min="1" max="10">
                    </div>
                    <button type="submit" class="btn btn-primary w-100">Adivinar</button>
                </form>
            <?php endif; ?>

            <?php if ($mensaje): ?>
                <div class="alert alert-info mt-4" id="mensaje"><?= $mensaje ?></div>
            <?php endif; ?>

            <?php if ($mostrarBotonReiniciar): ?>
                <form method="POST" class="mt-4">
                    <button type="submit" name="reiniciar" class="btn btn-success w-100">🔁 Jugar de Nuevo</button>
                </form>
            <?php endif; ?>

            <div class="text-center mt-4">
                <a href="../../index.php" class="btn btn-outline-secondary w-100">🏠 Regresar al Menú Principal</a>
            </div>
        </div>
    </div>

    <script src="js/juego.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

