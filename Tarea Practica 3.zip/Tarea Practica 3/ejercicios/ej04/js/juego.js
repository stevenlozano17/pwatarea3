function validarEntrada() {
    const input = document.getElementById("adivinanza").value.trim();
    if (input === "") {
        alert("⚠️ Debes ingresar un número antes de continuar.");
        return false;
    }
    const numero = parseInt(input);
    if (isNaN(numero) || numero < 1 || numero > 10) {
        alert("❌ El número debe estar entre 1 y 10.");
        return false;
    }
    return true;
}