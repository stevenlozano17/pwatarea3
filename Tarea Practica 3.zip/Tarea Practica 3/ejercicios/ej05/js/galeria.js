document.addEventListener("DOMContentLoaded", () => {
    const imagenes = document.querySelectorAll(".galeria-item img");
    const modal = new bootstrap.Modal(document.getElementById("modalImagen"));
    const imagenModal = document.getElementById("imagenModal");

    imagenes.forEach(img => {
        img.addEventListener("click", () => {
            imagenModal.src = img.src;
            modal.show();
        });
    });
});
