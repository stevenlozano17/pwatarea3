<?php
$directorio = "imagenes/";

$imagenes = array_diff(scandir($directorio), array('..', '.'));

$imagenes = array_slice($imagenes, 0, 5);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Galería de Imágenes</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/estilo.css">
</head>
<body>
    <div class="container py-5">
        <h1 class="text-center mb-4 text-light">📸 Galería de Imágenes</h1>
        <p class="text-center text-secondary mb-5">Galería de mis 5 juegos de pelea que más juego</p>

        <div class="row g-4 justify-content-center">
            <?php
            if (count($imagenes) > 0) {
                foreach ($imagenes as $imagen) {
                    $ruta = $directorio . $imagen;
                    echo "
                    <div class='col-sm-6 col-md-4 col-lg-3'>
                        <div class='card bg-dark border-light shadow-sm galeria-item'>
                            <img src='$ruta' class='card-img-top img-thumbnail' alt='Imagen de galería'>
                        </div>
                    </div>
                    ";
                }
            } else {
                echo "<p class='text-center text-warning'>No hay imágenes en la carpeta.</p>";
            }
            ?>
        </div>
    </div>
    <div class="modal fade" id="modalImagen" tabindex="-1" aria-hidden="true">
      <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content bg-dark border-light">
          <div class="modal-body text-center">
            <img src='' id='imagenModal' class='img-fluid rounded'>
          </div>
        </div>
      </div>
    </div>
    <div class="text-center mt-4">
       <a href="../../index.php" class="btn btn-outline-success btn-sm px-4 py-2" style="border-width: 2px; border-radius: 10px;">
           🏠 Regresar al Menú Principal
       </a>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="js/script.js"></script>
</body>
</html>
